// Step 2: Optimize Data

// Importing necessary modules
import fs from 'fs'; // ESM import
import data from './data.json' assert { type: 'json' }; // Importing JSON

// Function to optimize data
function optimizeData() {
  // Your optimization logic here
  console.log('Optimizing data...');

  // Example optimization: Filter out users with no email
  const optimizedData = data.filter((user) => user.email);
  console.log('Optimized Data:', optimizedData);

  // Optionally, save the optimized data to a new file
  fs.writeFileSync(
    'optimizedData.json',
    JSON.stringify(optimizedData, null, 2)
  );
}

// Call the function
optimizeData();
