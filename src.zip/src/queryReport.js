import { MongoClient } from 'mongodb';

// Replace with your actual connection string
const uri =
  'mongodb+srv://sfisondzobo:<4z2XZPZ9EMSt8Jqs>@fullstack.4woly.mongodb.net/?retryWrites=true&w=majority&appName=fullStack';
const client = new MongoClient(uri);

async function fetchReport() {
  try {
    await client.connect();
    const database = client.db('userdb'); // Ensure this database exists
    const collection = database.collection('users');

    // Your query logic here
    const results = await collection.find({}).toArray();
    console.log(results);
  } finally {
    await client.close();
  }
}

fetchReport();
