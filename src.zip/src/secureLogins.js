// Step 1: Simulate Secure Login Form Submission

// Import necessary libraries using ES modules
import axios from 'axios'; // For making HTTP requests
import express from 'express'; // To create a small server for CSRF simulation
import csrf from 'csurf'; // CSRF protection
import { writeFileSync } from 'fs'; // For writing to a file (Node.js)

// Create an express app for CSRF token generation
const app = express();
const csrfProtection = csrf({ cookie: true });

// login form
async function simulateLogin() {
  try {
    const response = await axios.post(
      'https://challenge.sedilink.co.za:12022',
      {
        username: 'sfiso.ndzobo@gmail.com',
        password: '8F700E834D0',
        action: 'LOGIN',
      },
      {
        headers: {
          'Content-Type': 'application/json',
        },
      }
    );

    console.log('Login successful, token received:', response.data.token);

    // Save users array to 'users.json' (works in Node.js)
    const users = response.data.users;

    // Check if you're in a Node.js environment before writing to a file
    if (typeof writeFileSync !== 'undefined') {
      writeFileSync('users.json', JSON.stringify(users, null, 2));
      console.log('Users saved to users.json');
    } else {
      console.log('File system not supported in this environment');
    }
  } catch (error) {
    console.error('Login failed:', error.message);
  }
}

// Call the function to simulate login
simulateLogin();
