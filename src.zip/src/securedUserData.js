import axios from 'axios';
import { readFileSync } from 'fs';

// Load unique users from uniqueUsers.json
const uniqueUsers = JSON.parse(readFileSync('src/uniqueUsers.json', 'utf-8'));

// Function to login and obtain a token
async function login() {
  const username = 'sfiso.ndzobo@gmail.com';
  const password = '8F700E834D0';

  try {
    const response = await axios.post('https://example.com/login', {
      // Replace with your actual login endpoint
      username,
      password,
    });
    const token = response.data.token; // Assuming the token is returned in the response
    console.log('Token:', token);
    return token;
  } catch (error) {
    console.error('Login failed:', error.message);
    return null;
  }
}

async function postUserData(token) {
  for (const user of uniqueUsers) {
    try {
      const response = await axios.post(
        'https://challenge.sedilink.co.za:12022',
        {
          name: user.name,
          surname: user.surname,
          designation: user.designation,
          department: user.department,
          id: user.id,
          token: token, // Sending the token in the request body (if required by the API)
        },
        {
          headers: {
            Authorization: `Bearer ${token}`, // Include the token in the headers (if required by the API)
          },
        }
      );
      console.log(`User ${user.name} posted successfully.`);
    } catch (error) {
      console.error(`Error posting user ${user.name}:`, error.message);
    }
  }
}

// Main function to orchestrate the login and posting
async function main() {
  const token = await login();
  if (token) {
    await postUserData(token);
  } else {
    console.error('Unable to obtain token, user data posting aborted.');
  }
}

// Execute the main function
main();
